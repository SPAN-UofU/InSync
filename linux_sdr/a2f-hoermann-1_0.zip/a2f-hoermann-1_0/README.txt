This is the Libero project for the Hoermann IMG's SmartFusion Embedded Evaluation Board with A2F500M3G-FGG484 device. The project is created with Actel's Libero Project Manager, version 9.1.3.4.

There are some recommendations below that we believe will help you to work with this design:

1. It is recommended to unpack the Libero project archive in C:\Actelprj directory. In that case Libero Project Manager and FlashPro will be able to correctly find all dependencies of the project.

2. We recommend to use the synthesize.tcl script (located at ..\a2f-hoermann-1_0\synthesis) to synthesize the design in the Synplify tool. This script is needed to pick up the timing constraint file synthesis.sdc (located at ..\a2f-hoermann-1_0\constraint). 

3. We also recommend to use the designer.tcl script (located at ..\a2f-hoermann-1_0\designer\impl1) to implement the design in the Actel Designer Tool. This script is needed to pick up the physical and timing constraint files designer.pdc and designer.sdc (located at ....\a2f-hoermann-1_0\constraint).
 
Note that if you are going to use our .tcl files to synthesize and generate an FPGA design,
you should apply your design changes (such as pin assignments or other physical constraint
changes) to the designer.pdc file and all timing constraints to the designer.sdc and synthesis.sdc files. 

4. ATTENTION! THIS PROJECT DOES NOT CONTAIN THE U-BOOT FIRMWARE IMAGE!
To program the SmartFusion with the U-Boot firmware please do the following:
 - build the U-Boot for your board according to the instructions in the User's Manual.
 - after building the "u-boot.bin" image execute "make u-boot.hex"
 - place the resulted ".hex" file to the ..\a2f-hoermann-1_0\Emcraft_Firmware directory
 - Being in FlashPro click the "Modify.." button in the "Programming file" window of the FlashPro. In the new window that appears after, press another "Modify" button related to the eNVM configuration.
 - click "Import Content" button in the "Modify Embedded Flash Memory" window and choose the u-boot.hex that you have already copied to the ..\a2f-hoermann-1_0\Emcraft_Firmware directory of your Libero project
 - choose "PROGRAM" or "PROGRAM_NVM" in the "Action" window and then reprogram the SmartFusion

