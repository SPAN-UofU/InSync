#ifndef TOPLEVEL_HW_PLATFORM_H_
#define TOPLEVEL_HW_PLATFORM_H_
/*****************************************************************************
*
*Created by Actel SmartDesign  Tue Oct 04 12:15:32 2011
*
*Memory map specification for peripherals in TOPLEVEL
*/

/*-----------------------------------------------------------------------------
* MSS_CORE_0 subsystem memory map
* Master(s) for this subsystem: MSS_CORE_0 
*---------------------------------------------------------------------------*/
#define COREINTERRUPT_0                 0x40050000U
#define VERSIONROM_0                    0x40050100U
#define COREGPIO_0                      0x40050200U
#define PSRAM_CR_0                      0x40050300U


#endif /* TOPLEVEL_HW_PLATFORM_H_*/
